﻿using System;
namespace HelloWorld
{
    class Program
    {
        static void Main(string[] args) // Точка входа
        {
            Console.WriteLine("Hello, World!/Hello/World!!!/!!!"); // Вывод в консоль 1
            //Console.Write("Hello, World!!!"); // Вывод в консоль 2
            //Console.Write("Hello"); // Вывод в консоль 3
            //Console.Write(" World!!!"); // Вывод в консоль 4
            //Console.Write("!!!"); // Вывод в консоль 5
        }

    }

}

